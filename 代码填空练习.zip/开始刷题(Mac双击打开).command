#!/bin/bash
open "$(dirname "$0")/index.html"
